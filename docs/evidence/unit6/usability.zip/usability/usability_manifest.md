# Usability Evidence Manifest

Prepared 2026-10-14. Classifies each item of the participant usability study as **observed** (recorded by the researcher during a session), **measured** (counted or averaged from recorded data), **interpreted** (researcher's reading of observed and measured data), or **prepared** (template or plan, contains no results).

| File | Kind | Content | State on 2026-10-14 |
| --- | --- | --- | --- |
| test_plan.md | prepared | Study design, tasks, success criteria, procedure, data handling, pre-session checklist | complete, no results |
| participant_instructions.md | prepared | Consent text and task scripts read to participants | complete |
| observation_form.md | prepared | Researcher's per-participant log: ID, category, date, per-task status, help given, difficulty, verbatim comments, optional duration | complete, blank |
| participant_feedback_form.md | prepared | Five 1-5 ratings and an open suggestion field | complete, blank |
| usability_results.csv | observed (when filled) | One row per participant per task | **header only, no data** |
| usability_feedback.csv | observed (when filled) | One row per participant | **header only, no data** |
| usability_summary.md | measured + interpreted (when produced) | Counts, rates, Table 2, rating means, themes | **placeholder, no data** |
| B05_task_completion_chart.png | measured (when produced) | Independent completion rate per task | **not created; requires data** |
| participant_usability_section.md | interpreted (when produced) | 130-180 word Part B subsection | **not created; requires data** |
| ../scripts/analyze_usability.py | prepared | Produces the summary, chart and figures from the CSVs; exits with an error while they are empty | complete |

Rules applied: no participant, rating, comment, timestamp or outcome is written by anyone other than the researcher transcribing a real session; participant ratings, observed behaviour and interpretation are kept in separate sections; the expert interface inspection already in the Unit 6 draft is a different method and is not counted as participant testing; production credentials appear in no file in this folder.
